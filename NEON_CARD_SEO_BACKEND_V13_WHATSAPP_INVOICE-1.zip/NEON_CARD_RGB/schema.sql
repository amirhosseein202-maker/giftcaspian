CREATE TABLE IF NOT EXISTS products (
  id INT UNSIGNED NOT NULL PRIMARY KEY,
  name_fa VARCHAR(180) NOT NULL,
  name_en VARCHAR(180) NOT NULL,
  category VARCHAR(40) NOT NULL,
  value_label VARCHAR(80) DEFAULT NULL,
  price BIGINT UNSIGNED NOT NULL DEFAULT 0,
  stock TINYINT(1) NOT NULL DEFAULT 1,
  image_url TEXT DEFAULT NULL,
  description TEXT DEFAULT NULL,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS orders (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  order_no VARCHAR(40) NOT NULL UNIQUE,
  customer_name VARCHAR(120) NOT NULL,
  phone VARCHAR(40) NOT NULL,
  email VARCHAR(180) DEFAULT NULL,
  note VARCHAR(1000) DEFAULT NULL,
  total BIGINT UNSIGNED NOT NULL,
  status VARCHAR(30) NOT NULL DEFAULT 'pending',
  gateway_ref VARCHAR(120) DEFAULT NULL,
  items_json LONGTEXT NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  paid_at TIMESTAMP NULL DEFAULT NULL,
  INDEX(status), INDEX(phone)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO products (id,name_fa,name_en,category,value_label,price,stock,description) VALUES
(1,'گیفت کارت اپل','Apple Gift Card','store','10 USD',690000,1,'گیفت کارت دیجیتال اپل'),
(2,'گیفت کارت گوگل پلی','Google Play','store','10 USD',720000,1,'گیفت کارت دیجیتال گوگل پلی'),
(3,'گیفت کارت آمازون','Amazon','store','10 USD',740000,1,'گیفت کارت دیجیتال آمازون'),
(4,'گیفت کارت استیم','Steam','gaming','10 USD',760000,1,'گیفت کارت دیجیتال استیم'),
(5,'گیفت کارت پلی‌استیشن','PlayStation','gaming','10 USD',780000,1,'گیفت کارت دیجیتال پلی‌استیشن'),
(6,'گیفت کارت ایکس‌باکس','Xbox','gaming','10 USD',770000,1,'گیفت کارت دیجیتال ایکس‌باکس'),
(7,'گیفت کارت نینتندو','Nintendo eShop','gaming','10 USD',800000,0,'گیفت کارت دیجیتال نینتندو'),
(8,'گیفت کارت ریزر گلد','Razer Gold','gaming','10 USD',790000,1,'گیفت کارت دیجیتال ریزر گلد'),
(9,'گیفت کارت اسپاتیفای','Spotify','subscription','1 Month',650000,1,'اشتراک دیجیتال اسپاتیفای'),
(10,'گیفت کارت نتفلیکس','Netflix','subscription','1 Month',900000,0,'اشتراک دیجیتال نتفلیکس'),
(11,'گیفت کارت روبلاکس','Roblox','gaming','10 USD',735000,1,'گیفت کارت دیجیتال روبلاکس'),
(12,'گیفت کارت ولورانت','Valorant','gaming','10 USD',755000,1,'گیفت کارت دیجیتال ولورانت')
ON DUPLICATE KEY UPDATE price=VALUES(price), stock=VALUES(stock), description=VALUES(description);
