<?php
declare(strict_types=1);
require __DIR__.'/security.php';
if($_SERVER['REQUEST_METHOD']!=='GET') send_json(['ok'=>false,'error'=>'method_not_allowed'],405);
try{ db(load_config())->query('SELECT 1'); send_json(['ok'=>true]); }catch(Throwable $e){ send_json(['ok'=>false,'error'=>'service_unavailable'],503); }
