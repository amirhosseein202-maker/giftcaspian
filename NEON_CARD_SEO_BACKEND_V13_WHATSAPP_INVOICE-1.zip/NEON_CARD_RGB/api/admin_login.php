<?php
declare(strict_types=1);
require __DIR__.'/security.php';
if($_SERVER['REQUEST_METHOD']!=='POST') send_json(['ok'=>false,'error'=>'method_not_allowed'],405);
rate_limit('admin-login:'.client_ip(), 8, 300);
$c=load_config(); $data=json_decode(file_get_contents('php://input'),true) ?: [];
$password=(string)($data['password']??'');
if(!password_verify($password,(string)($c['admin_password_hash']??''))) send_json(['ok'=>false,'error'=>'invalid_credentials'],401);
start_secure_session(); session_regenerate_id(true); $_SESSION['admin_id']='admin'; $_SESSION['login_at']=time(); $_SESSION['csrf']=bin2hex(random_bytes(32));
send_json(['ok'=>true,'csrf'=>$_SESSION['csrf']]);
