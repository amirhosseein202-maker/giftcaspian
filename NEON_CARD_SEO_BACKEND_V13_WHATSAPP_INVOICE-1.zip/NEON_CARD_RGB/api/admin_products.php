<?php
declare(strict_types=1);
require __DIR__.'/security.php';
start_secure_session(); require_admin();
if($_SERVER['REQUEST_METHOD']==='GET'){
  $rows=db(load_config())->query('SELECT id,name_fa,name_en,category,value_label,price,stock,image_url,description,updated_at FROM products ORDER BY id ASC')->fetchAll();
  send_json(['ok'=>true,'products'=>$rows]);
}
if($_SERVER['REQUEST_METHOD']!=='POST') send_json(['ok'=>false,'error'=>'method_not_allowed'],405);
require_csrf(); rate_limit('admin-write:'.client_ip(),30,60); $c=load_config(); $d=json_decode(file_get_contents('php://input'),true) ?: []; $action=$d['action']??''; $pdo=db($c);
try{
  if($action==='delete'){ $id=(int)($d['id']??0); if($id<1)send_json(['ok'=>false,'error'=>'invalid_id'],400); $s=$pdo->prepare('DELETE FROM products WHERE id=?');$s->execute([$id]);send_json(['ok'=>true]); }
  if($action==='upsert'){
    $id=(int)($d['id']??0); $name=trim((string)($d['name_fa']??'')); $en=trim((string)($d['name_en']??'')); $cat=trim((string)($d['category']??'')); $value=trim((string)($d['value_label']??'')); $price=(int)($d['price']??0); $stock=!empty($d['stock'])?1:0; $img=trim((string)($d['image_url']??'')); $desc=trim((string)($d['description']??''));
    if($id<1||$name===''||$en===''||$cat===''||$price<0||mb_strlen($name)>180||mb_strlen($en)>180||mb_strlen($cat)>40||mb_strlen($img)>2000||mb_strlen($desc)>5000)send_json(['ok'=>false,'error'=>'invalid_product'],400);
    $q=$pdo->prepare('INSERT INTO products(id,name_fa,name_en,category,value_label,price,stock,image_url,description) VALUES(?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE name_fa=VALUES(name_fa),name_en=VALUES(name_en),category=VALUES(category),value_label=VALUES(value_label),price=VALUES(price),stock=VALUES(stock),image_url=VALUES(image_url),description=VALUES(description)');
    $q->execute([$id,$name,$en,$cat,$value?:null,$price,$stock,$img?:null,$desc?:null]); send_json(['ok'=>true]);
  }
  send_json(['ok'=>false,'error'=>'unknown_action'],400);
}catch(Throwable $e){send_json(['ok'=>false,'error'=>'operation_failed'],400);}
