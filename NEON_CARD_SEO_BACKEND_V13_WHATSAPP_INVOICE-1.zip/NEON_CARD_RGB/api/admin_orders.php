<?php
declare(strict_types=1);
require __DIR__.'/security.php';
start_secure_session();
require_admin();
$c=load_config();
if($_SERVER['REQUEST_METHOD']==='GET'){
  $limit=min(200,max(1,(int)($_GET['limit']??100)));
  $stmt=db($c)->prepare('SELECT id,order_no,customer_name,phone,email,note,total,status,gateway_ref,items_json,created_at,paid_at FROM orders ORDER BY id DESC LIMIT '.$limit);
  $stmt->execute();
  $rows=$stmt->fetchAll();
  foreach($rows as &$row){$row['items']=json_decode((string)$row['items_json'],true) ?: []; unset($row['items_json']);}
  send_json(['ok'=>true,'orders'=>$rows]);
}
if($_SERVER['REQUEST_METHOD']!=='POST') send_json(['ok'=>false,'error'=>'method_not_allowed'],405);
require_csrf();
rate_limit('admin-orders-write:'.client_ip(),30,60);
$d=json_decode(file_get_contents('php://input'),true) ?: [];
if(($d['action']??'')!=='status') send_json(['ok'=>false,'error'=>'unknown_action'],400);
$id=(int)($d['id']??0); $status=(string)($d['status']??'');
$allowed=['pending','paid','expired','cancelled'];
if($id<1 || !in_array($status,$allowed,true)) send_json(['ok'=>false,'error'=>'invalid_status'],400);
$pdo=db($c);
if($status==='paid'){
  $q=$pdo->prepare("UPDATE orders SET status='paid',paid_at=COALESCE(paid_at,NOW()) WHERE id=?");
}else{
  $q=$pdo->prepare('UPDATE orders SET status=?,paid_at=NULL WHERE id=?');
  $q->execute([$status,$id]);
  send_json(['ok'=>true]);
}
$q->execute([$id]);
send_json(['ok'=>true]);
