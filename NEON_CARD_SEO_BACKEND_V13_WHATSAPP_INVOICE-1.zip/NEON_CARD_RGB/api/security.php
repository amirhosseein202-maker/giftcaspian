<?php
declare(strict_types=1);

function send_json(array $data, int $status = 200): never {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store, no-cache, must-revalidate');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function security_headers(): void {
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: DENY');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('Permissions-Policy: geolocation=(), microphone=(), camera=()');
    if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
        header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
    }
}
security_headers();

function load_config(): array {
    $file = __DIR__ . '/config.php';
    if (!is_file($file)) send_json(['ok'=>false,'error'=>'backend_not_configured'], 503);
    $config = require $file;
    if (!is_array($config)) send_json(['ok'=>false,'error'=>'invalid_config'], 500);
    return $config;
}

function db(array $c): PDO {
    static $pdo = null;
    if ($pdo instanceof PDO) return $pdo;
    $pdo = new PDO(
        'mysql:host='.$c['db_host'].';dbname='.$c['db_name'].';charset='.($c['db_charset'] ?? 'utf8mb4'),
        $c['db_user'], $c['db_pass'],
        [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC, PDO::ATTR_EMULATE_PREPARES=>false]
    );
    return $pdo;
}

function start_secure_session(): void {
    if (session_status() === PHP_SESSION_ACTIVE) return;
    session_name('neon_admin');
    session_set_cookie_params([
        'lifetime'=>0,'path'=>'/','secure'=>(!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'),
        'httponly'=>true,'samesite'=>'Lax'
    ]);
    session_start();
}

function csrf_token(): string {
    start_secure_session();
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf'];
}

function require_csrf(): void {
    start_secure_session();
    $token = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    if (!$token || empty($_SESSION['csrf']) || !hash_equals($_SESSION['csrf'], $token)) {
        send_json(['ok'=>false,'error'=>'csrf_failed'], 403);
    }
}

function require_admin(): void {
    start_secure_session();
    if (empty($_SESSION['admin_id'])) send_json(['ok'=>false,'error'=>'unauthorized'], 401);
}

function client_ip(): string {
    return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
}

function rate_limit(string $key, int $max, int $window): void {
    $dir = __DIR__ . '/.ratelimit';
    if (!is_dir($dir)) @mkdir($dir, 0700, true);
    $file = $dir . '/' . hash('sha256', $key) . '.json';
    $now = time(); $data = ['start'=>$now,'count'=>0];
    if (is_file($file)) {
        $old = json_decode((string)@file_get_contents($file), true);
        if (is_array($old) && ($now - (int)($old['start'] ?? 0)) < $window) $data = $old;
    }
    if (($now - (int)$data['start']) >= $window) $data = ['start'=>$now,'count'=>0];
    $data['count']++;
    @file_put_contents($file, json_encode($data), LOCK_EX);
    if ($data['count'] > $max) send_json(['ok'=>false,'error'=>'rate_limited'], 429);
}
