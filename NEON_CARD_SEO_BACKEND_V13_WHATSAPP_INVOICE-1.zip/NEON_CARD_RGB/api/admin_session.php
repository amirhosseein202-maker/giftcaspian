<?php
declare(strict_types=1);
require __DIR__.'/security.php';
start_secure_session();
send_json(['ok'=>true,'authenticated'=>!empty($_SESSION['admin_id']),'csrf'=>!empty($_SESSION['admin_id'])?csrf_token():null]);
