<?php
declare(strict_types=1);
require __DIR__.'/security.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') send_json(['ok'=>false,'error'=>'method_not_allowed'],405);
rate_limit('order:'.client_ip(), 20, 60);
$c=load_config();
try {
  $data=json_decode(file_get_contents('php://input'),true,512,JSON_THROW_ON_ERROR);
  $name=trim((string)($data['name']??'')); $phone=trim((string)($data['phone']??''));
  $email=trim((string)($data['email']??'')); $note=trim((string)($data['note']??'')); $items=$data['items']??[];
  if($name===''||$phone===''||!is_array($items)||count($items)<1) throw new RuntimeException('invalid_order');
  if(mb_strlen($name)>120||mb_strlen($phone)>40||mb_strlen($email)>180||mb_strlen($note)>1000) throw new RuntimeException('field_too_long');
  if($email!=='' && !filter_var($email,FILTER_VALIDATE_EMAIL)) throw new RuntimeException('invalid_email');
  if(!preg_match('/^[0-9+()\-\s]{7,40}$/',$phone)) throw new RuntimeException('invalid_phone');
  $pdo=db($c); $pdo->beginTransaction(); $total=0; $clean=[];
  $stmt=$pdo->prepare('SELECT id,name_fa,price,stock FROM products WHERE id=? LIMIT 1');
  foreach($items as $item){
    $id=(int)($item['id']??0); $qty=(int)($item['qty']??0);
    if($id<1||$qty<1||$qty>99) throw new RuntimeException('invalid_item');
    $stmt->execute([$id]); $p=$stmt->fetch();
    if(!$p || !(bool)$p['stock']) throw new RuntimeException('product_unavailable');
    $line=(int)$p['price']*$qty; $total += $line;
    if($total>PHP_INT_MAX) throw new RuntimeException('invalid_total');
    $clean[]=['id'=>$id,'name'=>$p['name_fa'],'qty'=>$qty,'unit_price'=>(int)$p['price'],'line_total'=>$line];
  }
  if($total<1) throw new RuntimeException('invalid_total');
  $orderNo='NC-'.date('ymdHis').'-'.strtoupper(bin2hex(random_bytes(4)));
  $ins=$pdo->prepare('INSERT INTO orders(order_no,customer_name,phone,email,note,total,status,items_json) VALUES(?,?,?,?,?,?,?,?)');
  $ins->execute([$orderNo,$name,$phone,$email?:null,$note?:null,$total,'pending',json_encode($clean,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)]);
  $pdo->commit();
  send_json(['ok'=>true,'orderNo'=>$orderNo,'total'=>$total,'status'=>'pending']);
}catch(JsonException $e){if(isset($pdo)&&$pdo->inTransaction())$pdo->rollBack();send_json(['ok'=>false,'error'=>'invalid_json'],400);
}catch(Throwable $e){if(isset($pdo)&&$pdo->inTransaction())$pdo->rollBack();send_json(['ok'=>false,'error'=>'request_rejected'],400);}
