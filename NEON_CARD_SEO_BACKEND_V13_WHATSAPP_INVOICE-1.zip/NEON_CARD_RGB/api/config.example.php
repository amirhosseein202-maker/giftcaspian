<?php
// این فایل را به config.php تغییر نام بده و فقط روی هاست نگه دار.
// رمز مدیر را حتماً قبل از استفاده واقعی تغییر بده.
return [
  'db_host' => 'localhost',
  'db_name' => 'YOUR_DATABASE',
  'db_user' => 'YOUR_DB_USER',
  'db_pass' => 'YOUR_DB_PASSWORD',
  'db_charset' => 'utf8mb4',
  'site_url' => 'https://YOUR-DOMAIN.example',
  'admin_password_hash' => '$2y$12$5D.FdLw/xtJKjBLEsy/fcu4uuSRI7TQ1mp9NZ8GPgFWjwr33MlbVG'
];
