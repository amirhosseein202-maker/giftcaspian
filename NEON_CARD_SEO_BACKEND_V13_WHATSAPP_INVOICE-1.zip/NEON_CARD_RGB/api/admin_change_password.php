<?php
declare(strict_types=1);
require __DIR__.'/security.php';
start_secure_session();
require_admin();
if($_SERVER['REQUEST_METHOD']!=='POST') send_json(['ok'=>false,'error'=>'method_not_allowed'],405);
require_csrf(); rate_limit('admin-pass:'.client_ip(),5,300);
$d=json_decode(file_get_contents('php://input'),true) ?: [];
$new=(string)($d['new_password']??'');
if(strlen($new)<8 || strlen($new)>200) send_json(['ok'=>false,'error'=>'password_too_short'],400);
$c=load_config();
$path=__DIR__.'/config.php';
if(!is_file($path) || !is_writable($path)) send_json(['ok'=>false,'error'=>'config_not_writable'],500);
$cfg=file_get_contents($path);
$hash=password_hash($new,PASSWORD_DEFAULT);
$updated=preg_replace("/'admin_password_hash'\\s*=>\\s*'[^']*'/", "'admin_password_hash' => '".addslashes($hash)."'", $cfg, 1, $count);
if(!$updated || $count!==1) send_json(['ok'=>false,'error'=>'password_update_failed'],500);
if(file_put_contents($path,$updated,LOCK_EX)===false) send_json(['ok'=>false,'error'=>'password_update_failed'],500);
send_json(['ok'=>true]);
